from django.urls import path
from directed_project import views

urlpatterns = [
    path('', views.user_page, name='user_page'),
    path('admin', views.admin_page, name='admin_page')
]