
from django.shortcuts import render
import pymongo
import json
from pymongo import MongoClient

from django import forms

import email, smtplib, ssl

from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

def user_page(request):
    
    ### variable declarations ###
    mongoKeyList = []
    context = {}
    fieldsToBeQueriedList = []
    mongoQuery = {'$and': fieldsToBeQueriedList}
    resultsArray = []
    queryResultKeys = []
    resultsArrayForHtml = []
    
    ### MongoDB Connection ###
    client = MongoClient('mongodb://localhost:27017/')
    logDB = client.logDB
    logCol = logDB.logData
    
    ## find all unique keys in logCol collection ##
    for document in logCol.find({}): 
         mongoKeyList = mongoKeyList + list(document.keys())
    uniqueMongoKeyList = set(mongoKeyList)
    context['mongoKeyList'] = uniqueMongoKeyList
    
    ## Get search fields input values from Html##
    for mongoKey in list(uniqueMongoKeyList) :
        userInputFieldValue = request.POST.get(mongoKey)
        if userInputFieldValue != '' and userInputFieldValue != None:
            if userInputFieldValue.isnumeric() :
                fieldsToBeQueriedList.append({mongoKey : {'$in' : [userInputFieldValue, int(userInputFieldValue)]}})
            else :
                fieldsToBeQueriedList.append({mongoKey : userInputFieldValue})
                
    if len(fieldsToBeQueriedList) > 0 :
        context['fieldsToBeQueriedList'] = fieldsToBeQueriedList
        # query mongodb #
        queryResults = logCol.find(mongoQuery)
        # collect results in an array #
        for doc in queryResults:
            resultsArray.append(doc)
        # get unique list of keys in results array for display on html #
        for result in resultsArray :
            queryResultKeys = queryResultKeys +list(result.keys())
        uniqueQueryResultKeys = set(queryResultKeys)
        
        # Prepare the objects list for html #
        for result in resultsArray:
            resultsObjectForHtml = {}
            for key in uniqueQueryResultKeys:
                if key in result.keys():
                    resultsObjectForHtml[key] = result[key]
                else:
                    resultsObjectForHtml[key] = ''
            resultsArrayForHtml.append(resultsObjectForHtml)

        context['resultsArrayForHtml'] = resultsArrayForHtml
        context['uniqueQueryResultKeys'] = uniqueQueryResultKeys

    return render(request, 'user_page.html', context)

def admin_page(request):
    ## Inputs from Html ##
    fileNameFromHtml = request.POST.get('fileName')
    fieldsToConcealFromHtml = request.POST.get('fieldsToConceal')
    searchPatternFromHtml = request.POST.get('searchPattern')
    
    ## variable declarations ##
    adminPageContext = {}
    loginPageContext = {}
    fieldsToConcealByDefault = ["creditCard", "password"]
    adminPageContext['fieldsToConcealByDefault'] = fieldsToConcealByDefault
    errorsFoundInMongoList = []
    fieldsToConceal = []

    ### MongoDB Connection ###
    client = MongoClient('mongodb://localhost:27017/')
    logDB = client.logDB
    logCol = logDB.logData
    searchCol = logDB.searchData
    adminCol = logDB.adminData

    ### Read data from JSON file to MongoDB ###
    if fileNameFromHtml != None and fileNameFromHtml != '':
        with open(fileNameFromHtml) as json_file:
            jsonDataList = json.load(json_file)
            ## Log Concealment ##
            fieldsToConceal = fieldsToConcealByDefault + fieldsToConcealFromHtml.split(',')
            for data in jsonDataList:
                for key in data.keys():
                    if key in fieldsToConceal :
                        data[key] = "XXXX"
            logCol.insert_many(jsonDataList)
            adminPageContext['successNotification'] = 'File Uploaded Successfully!'
            logCol.create_index([('$**', 'text')])
            for doc in searchCol.find():
                if doc['type'] == 'error':
                    searchPatternList = doc['list']
                    for searchPattern in searchPatternList:
                        errorsFoundInMongoList = errorsFoundInMongoList + list(logCol.find({"$text": {"$search": searchPattern}}))
        if len(errorsFoundInMongoList) > 0 :
            outputFileName = 'C:/Users/fathiman/Documents/directed-project-2/data/Error_Data_File.txt'
            ### Write the errors to a file to send it as an attachment to user ###
            with open(outputFileName, 'w') as outfile:
                for error in errorsFoundInMongoList:
                    outfile.write('%s\n' % error)
                

            
            ### Email User ###
            subject = "Error Report"
            htmlBody = """\
                <html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <!--[if !mso]><!-->
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!--<![endif]-->
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="format-detection" content="telephone=no">
  <meta name="x-apple-disable-message-reformatting">
  <title></title>
  <style type="text/css">
    @media screen {
      @font-face {
        font-family: 'Fira Sans';
        font-style: normal;
        font-weight: 400;
        src: local('Fira Sans Regular'), local('FiraSans-Regular'), url(https://fonts.gstatic.com/s/firasans/v8/va9E4kDNxMZdWfMOD5Vvl4jLazX3dA.woff2) format('woff2');
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
      }
      @font-face {
        font-family: 'Fira Sans';
        font-style: normal;
        font-weight: 400;
        src: local('Fira Sans Regular'), local('FiraSans-Regular'), url(https://fonts.gstatic.com/s/firasans/v8/va9E4kDNxMZdWfMOD5Vvk4jLazX3dGTP.woff2) format('woff2');
        unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
      }
      @font-face {
        font-family: 'Fira Sans';
        font-style: normal;
        font-weight: 500;
        src: local('Fira Sans Medium'), local('FiraSans-Medium'), url(https://fonts.gstatic.com/s/firasans/v8/va9B4kDNxMZdWfMOD5VnZKveRhf6Xl7Glw.woff2) format('woff2');
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
      }
      @font-face {
        font-family: 'Fira Sans';
        font-style: normal;
        font-weight: 500;
        src: local('Fira Sans Medium'), local('FiraSans-Medium'), url(https://fonts.gstatic.com/s/firasans/v8/va9B4kDNxMZdWfMOD5VnZKveQhf6Xl7Gl3LX.woff2) format('woff2');
        unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
      }
      @font-face {
        font-family: 'Fira Sans';
        font-style: normal;
        font-weight: 700;
        src: local('Fira Sans Bold'), local('FiraSans-Bold'), url(https://fonts.gstatic.com/s/firasans/v8/va9B4kDNxMZdWfMOD5VnLK3eRhf6Xl7Glw.woff2) format('woff2');
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
      }
      @font-face {
        font-family: 'Fira Sans';
        font-style: normal;
        font-weight: 700;
        src: local('Fira Sans Bold'), local('FiraSans-Bold'), url(https://fonts.gstatic.com/s/firasans/v8/va9B4kDNxMZdWfMOD5VnLK3eQhf6Xl7Gl3LX.woff2) format('woff2');
        unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
      }
      @font-face {
        font-family: 'Fira Sans';
        font-style: normal;
        font-weight: 800;
        src: local('Fira Sans ExtraBold'), local('FiraSans-ExtraBold'), url(https://fonts.gstatic.com/s/firasans/v8/va9B4kDNxMZdWfMOD5VnMK7eRhf6Xl7Glw.woff2) format('woff2');
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
      }
      @font-face {
        font-family: 'Fira Sans';
        font-style: normal;
        font-weight: 800;
        src: local('Fira Sans ExtraBold'), local('FiraSans-ExtraBold'), url(https://fonts.gstatic.com/s/firasans/v8/va9B4kDNxMZdWfMOD5VnMK7eQhf6Xl7Gl3LX.woff2) format('woff2');
        unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
      }
    }

    #outlook a {
      padding: 0;
    }

    .ReadMsgBody,
    .ExternalClass {
      width: 100%;
    }

    .ExternalClass,
    .ExternalClass p,
    .ExternalClass td,
    .ExternalClass div,
    .ExternalClass span,
    .ExternalClass font {
      line-height: 100%;
    }

    div[style*="margin: 14px 0"],
    div[style*="margin: 16px 0"] {
      margin: 0 !important;
    }

    table,
    td {
      mso-table-lspace: 0;
      mso-table-rspace: 0;
    }

    table,
    tr,
    td {
      border-collapse: collapse;
    }

    body,
    td,
    th,
    p,
    div,
    li,
    a,
    span {
      -webkit-text-size-adjust: 100%;
      -ms-text-size-adjust: 100%;
      mso-line-height-rule: exactly;
    }

    img {
      border: 0;
      outline: none;
      line-height: 100%;
      text-decoration: none;
      -ms-interpolation-mode: bicubic;
    }

    a[x-apple-data-detectors] {
      color: inherit !important;
      text-decoration: none !important;
    }

    body {
      margin: 0;
      padding: 0;
      width: 100% !important;
      -webkit-font-smoothing: antialiased;
    }

    .pc-gmail-fix {
      display: none;
      display: none !important;
    }

    @media screen and (min-width: 621px) {
      .pc-email-container {
        width: 620px !important;
      }
    }

    @media screen and (max-width:620px) {
      .pc-sm-p-30-20 {
        padding: 30px 20px !important
      }
      .pc-sm-fs-30 {
        font-size: 30px !important
      }
      .pc-sm-fs-18 {
        font-size: 18px !important
      }
    }

    @media screen and (max-width:525px) {
      .pc-xs-p-25-10 {
        padding: 25px 10px !important
      }
      .pc-xs-fs-16 {
        font-size: 16px !important
      }
      .pc-xs-br-disabled br {
        display: none !important
      }
    }
  </style>
  <!--[if mso]>
    <style type="text/css">
        .pc-fb-font {
            font-family: Helvetica, Arial, sans-serif !important;
        }
    </style>
    <![endif]-->
  <!--[if gte mso 9]><xml><o:OfficeDocumentSettings><o:AllowPNG/><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml><![endif]-->
</head>
<body style="width: 100% !important; margin: 0; padding: 0; mso-line-height-rule: exactly; -webkit-font-smoothing: antialiased; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; background-color: #f4f4f4" class="">
  <span style="color: transparent; display: none; height: 0; max-height: 0; max-width: 0; opacity: 0; overflow: hidden; mso-hide: all; visibility: hidden; width: 0;">This is preheader text. Some clients will show this text as a preview.</span>
  <table class="pc-email-body" width="100%" bgcolor="#f4f4f4" border="0" cellpadding="0" cellspacing="0" role="presentation" style="table-layout: fixed;">
    <tbody>
      <tr>
        <td class="pc-email-body-inner" align="center" valign="top">
          <!--[if gte mso 9]>
            <v:background xmlns:v="urn:schemas-microsoft-com:vml" fill="t">
                <v:fill type="tile" src="" color="#f4f4f4"/>
            </v:background>
            <![endif]-->
          <!--[if (gte mso 9)|(IE)]><table width="620" align="center" border="0" cellspacing="0" cellpadding="0" role="presentation"><tr><td width="620" align="center" valign="top"><![endif]-->
          <table class="pc-email-container" width="100%" align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" style="margin: 0 auto; max-width: 620px;">
            <tbody>
              <tr>
                <td align="left" valign="top" style="padding: 0 10px;">
                  <table width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation">
                    <tbody>
                      <tr>
                        <td height="20" style="font-size: 1px; line-height: 1px;">&nbsp;</td>
                      </tr>
                    </tbody>
                  </table>
                  <!-- BEGIN MODULE: Transactional 1 -->
                  <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                    <tbody>
                      <tr>
                        <td class="pc-sm-p-30-20 pc-xs-p-25-10" style="padding: 40px 30px; background: #ffffff; border-radius: 8px;" bgcolor="#ffffff" valign="top">
                          <table width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation">
                            <tbody>
                              <tr>
                                <td class="pc-sm-fs-30 pc-fb-font" style="font-family: 'Fira Sans', Helvetica, Arial, sans-serif; font-size: 36px; font-weight: 800; line-height: 46px; letter-spacing: -0.6px; color: #151515; padding: 0 10px;" valign="top">Uploaded Log Data Report</td>
                              </tr>
                              <tr>
                                <td height="15" style="line-height: 1px; font-size: 1px;">&nbsp;</td>
                              </tr>
                            </tbody>
                            <tbody>
                              <tr>
                                <td class="pc-sm-fs-18 pc-xs-fs-16 pc-fb-font" style="font-family: 'Fira Sans', Helvetica, Arial, sans-serif; font-size: 20px; line-height: 30px; letter-spacing: -0.2px; color: #9B9B9B; padding: 0 10px" valign="top">You have just finished uploading logs to the database. Please find more details below :</td>
                              </tr>
                              <tr>
                                <td height="25" style="line-height: 1px; font-size: 1px;">&nbsp;</td>
                              </tr>
                            </tbody>
                            <tbody>
                              <tr>
                                <td style="padding: 0 10px;" valign="top">
                                  <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                    <tbody>
                                    </tbody>
                                    <tbody>
                                      <tr>
                                        <td style="padding: 20px 10px 20px 0; font-size: 16px; letter-spacing: -0.2px; line-height: 26px; font-family: 'Fira Sans', Helvetica, Arial, sans-serif; border-bottom: 1px solid #E5E5E5;" valign="top">
                                          <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                            <tbody>
                                              <tr>
                                                <td valign="top" style="font-size: 0;">
                                                  <!--[if (gte mso 9)|(IE)]><table role="presentation" cellspacing="0" cellpadding="0" border="0" width="400"><tr><td width="120" valign="top"><![endif]-->
                                                  <div style="display: inline-block; max-width: 120px; vertical-align: top;">
                                                    <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                                      <tbody>
                                                        <tr>
                                                          <td style="padding: 0 20px 0 0;" valign="top">
                                                            <img class="pc-fb-font" src="cid:0" width="100" alt="" style="border: 0; outline: 0; line-height: 100%; -ms-interpolation-mode: bicubic; display: block;" height="100">
                                                          </td>
                                                        </tr>
                                                      </tbody>
                                                    </table>
                                                  </div>
                                                  <!--[if (gte mso 9)|(IE)]></td><td width="280" valign="top"><![endif]-->
                                                  <div style="display: inline-block; max-width: 280px; vertical-align: top;">
                                                    <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                                      <tbody>
                                                        <tr>
                                                          <td style="padding: 9px 0 0;" valign="top">
                                                            <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                                              <tbody>
                                                                <tr>
                                                                  <td class="pc-fb-font" style="font-family: 'Fira Sans', Helvetica, Arial, sans-serif; letter-spacing: -0.3px; line-height: 28px; font-weight: 500; font-size: 18px; color: #151515; padding: 0 0 4px 0;" valign="top">File Name</td>
                                                                </tr>
                                                                <tr>
                                                                  <td height="4" style="font-size: 1px; line-height: 1px;">&nbsp;</td>
                                                                </tr>
                                                              </tbody>
                                                              <tbody>
                                                                <tr>
                                                                  <td class="pc-fb-font" style="font-family: 'Fira Sans', Helvetica, Arial, sans-serif; letter-spacing: -0.2px; line-height: 24px; font-size: 16px; color: #9B9B9B;;" valign="top">""" + fileNameFromHtml + """</td>
                                                                </tr>
                                                              </tbody>
                                                            </table>
                                                          </td>
                                                        </tr>
                                                      </tbody>
                                                    </table>
                                                  </div>
                                                  <!--[if (gte mso 9)|(IE)]></td></tr></table><![endif]-->
                                                </td>
                                              </tr>
                                            </tbody>
                                          </table>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td style="padding: 20px 10px 20px 0; letter-spacing: -0.2px; line-height: 26px; font-family: 'Fira Sans', Helvetica, Arial, sans-serif; font-size: 16px; border-bottom: 1px solid #E5E5E5;" valign="top">
                                          <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                            <tbody>
                                              <tr>
                                                <td valign="top" style="font-size: 0;">
                                                  <!--[if (gte mso 9)|(IE)]><table role="presentation" cellspacing="0" cellpadding="0" border="0" width="400"><tr><td width="120" style="vertical-align:top" valign="top"><![endif]-->
                                                  <div style="display: inline-block; max-width: 120px; vertical-align: top;">
                                                    <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                                      <tbody>
                                                        <tr>
                                                          <td style="padding: 0 20px 0 0;" valign="top">
                                                            <img class="pc-fb-font" src="cid:1" width="100" alt="" style="border: 0; outline: 0; line-height: 100%; -ms-interpolation-mode: bicubic; display: block;" height="">
                                                          </td>
                                                        </tr>
                                                      </tbody>
                                                    </table>
                                                  </div>
                                                  <!--[if (gte mso 9)|(IE)]></td><td width="280" valign="top"><![endif]-->
                                                  <div style="display: inline-block; max-width: 280px; vertical-align: top;">
                                                    <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                                      <tbody>
                                                        <tr>
                                                          <td style="padding: 9px 0 0;" valign="top">
                                                            <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                                              <tbody>
                                                                <tr>
                                                                  <td class="pc-fb-font" style="font-family: 'Fira Sans', Helvetica, Arial, sans-serif; letter-spacing: -0.3px; line-height: 28px; font-weight: 500; font-size: 18px; color: #151515;" valign="top">Concealed Fields</td>
                                                                </tr>
                                                                <tr>
                                                                  <td height="4" style="font-size: 1px; line-height: 1px;">&nbsp;</td>
                                                                </tr>
                                                              </tbody>
                                                              <tbody>
                                                                <tr>
                                                                  <td class="pc-fb-font" style="font-family: 'Fira Sans', Helvetica, Arial, sans-serif; letter-spacing: -0.2px; line-height: 24px; font-size: 16px; color: #9B9B9B;;" valign="top">""" + ','.join(fieldsToConceal)+"""</td>
                                                                </tr>
                                                              </tbody>
                                                            </table>
                                                          </td>
                                                        </tr>
                                                      </tbody>
                                                    </table>
                                                  </div>
                                                  <!--[if (gte mso 9)|(IE)]></td></tr></table><![endif]-->
                                                </td>
                                              </tr>
                                            </tbody>
                                          </table>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td style="padding: 20px 10px 20px 0; letter-spacing: -0.2px; line-height: 26px; font-family: 'Fira Sans', Helvetica, Arial, sans-serif; font-size: 16px; border-bottom: 1px solid #E5E5E5;" valign="top">
                                          <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                            <tbody>
                                              <tr>
                                                <td valign="top" style="font-size: 0;">
                                                  <!--[if (gte mso 9)|(IE)]><table role="presentation" cellspacing="0" cellpadding="0" border="0" width="400"><tr><td width="120" style="vertical-align:top" valign="top"><![endif]-->
                                                  <div style="display: inline-block; max-width: 120px; vertical-align: top;">
                                                    <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                                      <tbody>
                                                        <tr>
                                                          <td style="padding: 0 20px 0 0;" valign="top">
                                                            <img class="pc-fb-font" src="cid:2" width="100" alt="" style="border: 0; outline: 0; line-height: 100%; -ms-interpolation-mode: bicubic; display: block;" height="">
                                                          </td>
                                                        </tr>
                                                      </tbody>
                                                    </table>
                                                  </div>
                                                  <!--[if (gte mso 9)|(IE)]></td><td width="280" valign="top"><![endif]-->
                                                  <div style="display: inline-block; max-width: 280px; vertical-align: top;">
                                                    <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                                      <tbody>
                                                        <tr>
                                                          <td style="padding: 9px 0 0;" valign="top">
                                                            <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                                              <tbody>
                                                                <tr>
                                                                  <td class="pc-fb-font" style="font-family: 'Fira Sans', Helvetica, Arial, sans-serif; letter-spacing: -0.3px; line-height: 28px; font-weight: 500; font-size: 18px; color: #151515;" valign="top">Errors Detected ?</td>
                                                                </tr>
                                                                <tr>
                                                                  <td height="4" style="font-size: 1px; line-height: 1px;">&nbsp;</td>
                                                                </tr>
                                                              </tbody>
                                                              <tbody>
                                                                <tr>
                                                                  <td class="pc-fb-font" style="font-family: 'Fira Sans', Helvetica, Arial, sans-serif; letter-spacing: -0.2px; line-height: 24px; font-size: 16px; color: #9B9B9B;;" valign="top">Yes. Please refer to the attachment for more details</td>
                                                                </tr>
                                                              </tbody>
                                                            </table>
                                                          </td>
                                                        </tr>
                                                      </tbody>
                                                    </table>
                                                  </div>
                                                  <!--[if (gte mso 9)|(IE)]></td></tr></table><![endif]-->
                                                </td>
                                              </tr>
                                            </tbody>
                                          </table>
                                        </td>
                                      </tr>
                                    </tbody>
                                  </table>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <!-- END MODULE: Transactional 1 -->
                  <table width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation">
                    <tbody>
                      <tr>
                        <td height="20" style="font-size: 1px; line-height: 1px;">&nbsp;</td>
                      </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
            </tbody>
          </table>
          <!--[if (gte mso 9)|(IE)]></td></tr></table><![endif]-->
        </td>
      </tr>
    </tbody>
  </table>
  <!-- Fix for Gmail on iOS -->
  <div class="pc-gmail-fix" style="white-space: nowrap; font: 15px courier; line-height: 0;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </div>
</body>
</html>
            """
            sender_email = "nadirafathima1@gmail.com"
            receiver_email = "nadirafathima1@gmail.com"
            password = "password"
            # Create a multipart message and set headers
            message = MIMEMultipart()
            message["From"] = sender_email
            message["To"] = receiver_email
            message["Subject"] = subject
            message["Bcc"] = receiver_email  # Recommended for mass emails

            # Add body to email
            message.attach(MIMEText(htmlBody, "html"))

            # to add an attachment is just add a MIMEBase object to read a picture locally.
        with open('C:/Users/fathiman/Documents/directed-project-2/data/email_template/images/img1.jpg', 'rb') as f:
            # set attachment mime and file name, the image type is png
            mime = MIMEBase('image', 'png', filename='img1.png')
            # add required header data:
            mime.add_header('Content-Disposition', 'attachment', filename='img1.png')
            mime.add_header('X-Attachment-Id', '0')
            mime.add_header('Content-ID', '<0>')
            # read attachment file content into the MIMEBase object
            mime.set_payload(f.read())
            # encode with base64
            encoders.encode_base64(mime)
            # add MIMEBase object to MIMEMultipart object
            message.attach(mime)
  
        with open('C:/Users/fathiman/Documents/directed-project-2/data/email_template/images/img2.png', 'rb') as f:
            # set attachment mime and file name, the image type is png
            mime = MIMEBase('image', 'png', filename='img2.png')
            # add required header data:
            mime.add_header('Content-Disposition', 'attachment', filename='img2.png')
            mime.add_header('X-Attachment-Id', '1')
            mime.add_header('Content-ID', '<1>')
            # read attachment file content into the MIMEBase object
            mime.set_payload(f.read())
            # encode with base64
            encoders.encode_base64(mime)
            # add MIMEBase object to MIMEMultipart object
            message.attach(mime)
        
        with open('C:/Users/fathiman/Documents/directed-project-2/data/email_template/images/img3.jpeg', 'rb') as f:
            # set attachment mime and file name, the image type is png
            mime = MIMEBase('image', 'png', filename='img3.png')
            # add required header data:
            mime.add_header('Content-Disposition', 'attachment', filename='img3.png')
            mime.add_header('X-Attachment-Id', '2')
            mime.add_header('Content-ID', '<2>')
            # read attachment file content into the MIMEBase object
            mime.set_payload(f.read())
            # encode with base64
            encoders.encode_base64(mime)
            # add MIMEBase object to MIMEMultipart object
            message.attach(mime)

            
            # Open PDF file in binary mode
            with open(outputFileName, "rb") as attachment:
                # Add file as application/octet-stream
                # Email client can usually download this automatically as attachment
                part = MIMEBase("application", "octet-stream")
                part.set_payload(attachment.read())

            # Encode file in ASCII characters to send by email    
            encoders.encode_base64(part)

            # Add header as key/value pair to attachment part
            part.add_header(
                "Content-Disposition",
                f"attachment; filename= {outputFileName}",
            )

            # Add attachment to message and convert message to string
            message.attach(part)
            text = message.as_string()

            # Log in to server using secure context and send email
            ssl_context = ssl.create_default_context()
            with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=ssl_context) as server:
                server.login(sender_email, password)
                server.sendmail(sender_email, receiver_email, text)
            adminPageContext['emailNotification'] = 'Error Data Found in Uploaded File. Email sent successfully!'
        return render(request, 'admin_page.html', adminPageContext)
    ## Search pattern list processing from Html ##
    if searchPatternFromHtml != None and searchPatternFromHtml != '':
        searchPatternList = searchPatternFromHtml.split(',')
        for searchPattern in searchPatternList :
            if searchCol.find({'list': searchPattern}).count() == 0 :
                searchCol.update({'type': 'error'}, {'$push': {'list': searchPattern}})
        return render(request, 'admin_page.html', adminPageContext)
    
     ## Login Flow ##
    adminList = list(adminCol.find())
    for admin in adminList:
        isSuccessfulLogin = False
        if request.POST.get('userName') == admin['userName'] and request.POST.get('password') == admin['password'] :
            isSuccessfulLogin = True
            return render(request, 'admin_page.html', adminPageContext)
        if request.POST.get('userName')!= None and request.POST.get('password')!=None and isSuccessfulLogin == False:
            loginPageContext['notification'] = 'Invalid Credentials. Please try again!'
        
    return render(request, 'login_page.html', loginPageContext)
    