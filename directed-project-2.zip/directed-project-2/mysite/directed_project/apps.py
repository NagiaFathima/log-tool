from django.apps import AppConfig


class DirectedProjectConfig(AppConfig):
    name = 'directed_project'
