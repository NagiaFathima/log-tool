
from django.shortcuts import render
import pymongo
import json
from pymongo import MongoClient

from django import forms

import email, smtplib, ssl

from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def user_page(request):
    ### variable declarations ###
    mongoKeyList = []
    context = {}
    fieldsToBeQueriedList = []
    mongoQuery = {'$and': fieldsToBeQueriedList}
    resultsArray = []
    queryResultKeys = []
    resultsArrayForHtml = []
    
    ### MongoDB Connection ###
    client = MongoClient('mongodb://localhost:27017/')
    logDB = client.logDB
    logCol = logDB.logData
    
    ## find all unique keys in logCol collection ##
    for document in logCol.find({}): 
         mongoKeyList = mongoKeyList + list(document.keys())
    uniqueMongoKeyList = set(mongoKeyList)
    context['mongoKeyList'] = uniqueMongoKeyList
    
    ## Get search fields input values from Html##
    for mongoKey in list(uniqueMongoKeyList) :
        userInputFieldValue = request.POST.get(mongoKey)
        if userInputFieldValue != '' and userInputFieldValue != None:
            if userInputFieldValue.isnumeric() :
                fieldsToBeQueriedList.append({mongoKey : {'$in' : [userInputFieldValue, int(userInputFieldValue)]}})
            else :
                fieldsToBeQueriedList.append({mongoKey : userInputFieldValue})
                
    if len(fieldsToBeQueriedList) > 0 :
        # query mongodb #
        queryResults = logCol.find(mongoQuery)
        # collect results in an array #
        for doc in queryResults:
            resultsArray.append(doc)
        # get unique list of keys in results array for display on html #
        for result in resultsArray :
            queryResultKeys = queryResultKeys +list(result.keys())
        uniqueQueryResultKeys = set(queryResultKeys)
        
        # Prepare the objects list for html #
        for result in resultsArray:
            resultsObjectForHtml = {}
            for key in uniqueQueryResultKeys:
                if key in result.keys():
                    resultsObjectForHtml[key] = result[key]
                else:
                    resultsObjectForHtml[key] = ''
            resultsArrayForHtml.append(resultsObjectForHtml)
            
        context['resultsArrayForHtml'] = resultsArrayForHtml
        context['uniqueQueryResultKeys'] = uniqueQueryResultKeys

    return render(request, 'user_page.html', context)

def admin_page(request):
    ## Inputs from Html ##
    fileNameFromHtml = request.POST.get('fileName')
    fieldsToConcealFromHtml = request.POST.get('fieldsToConceal')
    searchPatternFromHtml = request.POST.get('searchPattern')
    
    ## variable declarations ##
    adminPageContext = {}
    loginPageContext = {}
    fieldsToConcealByDefault = ["creditCard", "password"]
    adminPageContext['fieldsToConcealByDefault'] = fieldsToConcealByDefault
    errorsFoundInMongoList = []

    ### MongoDB Connection ###
    client = MongoClient('mongodb://localhost:27017/')
    logDB = client.logDB
    logCol = logDB.logData
    searchCol = logDB.searchData
    adminCol = logDB.adminData

    ### Read data from JSON file to MongoDB ###
    if fileNameFromHtml != None and fileNameFromHtml != '':
        with open(fileNameFromHtml) as json_file:
            jsonDataList = json.load(json_file)
            ## Log Concealment ##
            fieldsToConceal = fieldsToConcealByDefault + fieldsToConcealFromHtml.split(',')
            for data in jsonDataList:
                for key in data.keys():
                    if key in fieldsToConceal :
                        data[key] = "XXXX"
            logCol.insert_many(jsonDataList)
            logCol.create_index([('$**', 'text')])
            for doc in searchCol.find():
                if doc['type'] == 'error':
                    searchPatternList = doc['list']
                    for searchPattern in searchPatternList:
                        errorsFoundInMongoList = errorsFoundInMongoList + list(logCol.find({"$text": {"$search": searchPattern}}))
        if len(errorsFoundInMongoList) > 0 :
            outputFileName = 'C:/Users/fathiman/Documents/directed-project-2/data/Error_Data_File.txt'
            ### Write the errors to a file to send it as an attachment to user ###
            with open(outputFileName, 'w') as outfile:
                for error in errorsFoundInMongoList:
                    outfile.write('%s\n' % error)
            
            ### Email User ###
            subject = "Error Report"
            htmlBody = """\
                <html>
                    <body>   
                    This is the body
                    </body>
                </html>"
            """
            sender_email = "nadirafathima1@gmail.com"
            receiver_email = "nadirafathima1@gmail.com"
            password = "password"
            # Create a multipart message and set headers
            message = MIMEMultipart()
            message["From"] = sender_email
            message["To"] = receiver_email
            message["Subject"] = subject
            message["Bcc"] = receiver_email  # Recommended for mass emails

            # Add body to email
            message.attach(MIMEText(htmlBody, "html"))

            # Open PDF file in binary mode
            with open(outputFileName, "rb") as attachment:
                # Add file as application/octet-stream
                # Email client can usually download this automatically as attachment
                part = MIMEBase("application", "octet-stream")
                part.set_payload(attachment.read())

            # Encode file in ASCII characters to send by email    
            encoders.encode_base64(part)

            # Add header as key/value pair to attachment part
            part.add_header(
                "Content-Disposition",
                f"attachment; filename= {outputFileName}",
            )

            # Add attachment to message and convert message to string
            message.attach(part)
            text = message.as_string()

            # Log in to server using secure context and send email
            ssl_context = ssl.create_default_context()
            with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=ssl_context) as server:
                server.login(sender_email, password)
                server.sendmail(sender_email, receiver_email, text)

    ## Search pattern list processing from Html ##
    if searchPatternFromHtml != None and searchPatternFromHtml != '':
        searchPatternList = searchPatternFromHtml.split(',')
        for searchPattern in searchPatternList :
            if searchCol.find({'list': searchPattern}).count() == 0 :
                searchCol.update({'type': 'error'}, {'$push': {'list': searchPattern}})
    
     ## Login Flow ##
    adminList = list(adminCol.find())
    for admin in adminList:
        isSuccessfulLogin = False
        if request.POST.get('userName') == admin['userName'] and request.POST.get('password') == admin['password'] :
            isSuccessfulLogin = True
            return render(request, 'admin_page.html', adminPageContext)
        if request.POST.get('userName')!= None and request.POST.get('password')!=None and isSuccessfulLogin == False:
            loginPageContext['notification'] = 'Invalid Credentials. Please try again!'
        
    return render(request, 'login_page.html', loginPageContext)
    